<?xml version='1.0' encoding='UTF-8'?><topic xsi:noNamespaceSchemaLocation="https://resources.jetbrains.com/writerside/1.0/topic.v2.xsd" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" id="how-to-manage-salary" title="How to Create a Salary Record in the Payroll System"> <title id="-ue51w5_2">
How to Create a Salary Record in the Payroll System
</title>
<p id="-ue51w5_3">This guide walks you through the steps to create a salary record in the payroll management system.</p>
<chapter id="step-1-open-the-salary-creation-form" title="Step 1: Open the Salary Creation Form">
<p id="-ue51w5_10">To begin, navigate to the <include from="how-to-manage-salary_auto-include.topic" element-id="-ue51w5_11-snippet"/> section and select <include from="how-to-manage-salary_auto-include.topic" element-id="-ue51w5_12-snippet"/>. This will open the salary creation form where you can enter details for the salary payment.</p>
</chapter>
<chapter id="step-2-fill-out-salary-details" title="Step 2: Fill Out Salary Details">
<p id="-ue51w5_13">In the form, you’ll find several fields to fill in:</p>
<chapter id="1-date-of-salary">
<title id="-ue51w5_22">
1. <include from="how-to-manage-salary_auto-include.topic" element-id="-ue51w5_24-snippet"/>
</title>
<list id="-ue51w5_23">
<li id="-ue51w5_25">Choose the date when the salary is issued.</li>
<li id="-ue51w5_26">Click on the <include from="how-to-manage-salary_auto-include.topic" element-id="-ue51w5_27-snippet"/> next to the &amp;quot;Date of Salary&amp;quot; field to pick a date.</li>
</list>
</chapter>
<chapter id="2-employee-selection">
<title id="-ue51w5_28">
2. <include from="how-to-manage-salary_auto-include.topic" element-id="-ue51w5_30-snippet"/>
</title>
<list id="-ue51w5_29">
<li id="-ue51w5_31">Use the <include from="how-to-manage-salary_auto-include.topic" element-id="-ue51w5_32-snippet"/> dropdown to select the employee for whom you're creating the salary record.</li>
</list>
</chapter>
<chapter id="3-salary-month">
<title id="-ue51w5_33">
3. <include from="how-to-manage-salary_auto-include.topic" element-id="-ue51w5_35-snippet"/>
</title>
<list id="-ue51w5_34">
<li id="-ue51w5_36">Choose the month for which this salary applies.</li>
<li id="-ue51w5_37">Click on the calendar icon to select the salary month.</li>
</list>
</chapter>
<chapter id="4-amount">
<title id="-ue51w5_38">
4. <include from="how-to-manage-salary_auto-include.topic" element-id="-ue51w5_40-snippet"/>
</title>
<list id="-ue51w5_39">
<li id="-ue51w5_41">Enter the base salary amount in the <include from="how-to-manage-salary_auto-include.topic" element-id="-ue51w5_42-snippet"/> field.</li>
</list>
</chapter>
<chapter id="5-festival-bonus">
<title id="-ue51w5_43">
5. <include from="how-to-manage-salary_auto-include.topic" element-id="-ue51w5_45-snippet"/>
</title>
<list id="-ue51w5_44">
<li id="-ue51w5_46">Add any festival bonus amount in the <include from="how-to-manage-salary_auto-include.topic" element-id="-ue51w5_47-snippet"/> field.</li>
</list>
</chapter>
<chapter id="6-other-bonus">
<title id="-ue51w5_48">
6. <include from="how-to-manage-salary_auto-include.topic" element-id="-ue51w5_50-snippet"/>
</title>
<list id="-ue51w5_49">
<li id="-ue51w5_51">If there are additional bonuses, enter them in the <include from="how-to-manage-salary_auto-include.topic" element-id="-ue51w5_52-snippet"/> field.</li>
</list>
</chapter>
<chapter id="7-deduction">
<title id="-ue51w5_53">
7. <include from="how-to-manage-salary_auto-include.topic" element-id="-ue51w5_55-snippet"/>
</title>
<list id="-ue51w5_54">
<li id="-ue51w5_56">Specify any deductions to be subtracted from the total in the <include from="how-to-manage-salary_auto-include.topic" element-id="-ue51w5_57-snippet"/> field.</li>
</list>
</chapter>
<chapter id="8-payment-method">
<title id="-ue51w5_58">
8. <include from="how-to-manage-salary_auto-include.topic" element-id="-ue51w5_60-snippet"/>
</title>
<list id="-ue51w5_59">
<li id="-ue51w5_61">Select the method of payment from the dropdown (e.g., <include from="how-to-manage-salary_auto-include.topic" element-id="-ue51w5_62-snippet"/>, <include from="how-to-manage-salary_auto-include.topic" element-id="-ue51w5_63-snippet"/>).</li>
</list>
</chapter>
</chapter>
<chapter id="step-3-check-the-total-amount" title="Step 3: Check the Total Amount">
<p id="-ue51w5_64">Once all fields are filled out, the <include from="how-to-manage-salary_auto-include.topic" element-id="-ue51w5_65-snippet"/> at the bottom of the form will automatically calculate the sum based on the entered values. Ensure this amount is correct.</p>
</chapter>
<chapter id="step-4-add-notes-optional" title="Step 4: Add Notes (Optional)">
<p id="-ue51w5_66">If there are any special remarks or details regarding this salary, you can add them in the <include from="how-to-manage-salary_auto-include.topic" element-id="-ue51w5_67-snippet"/> field at the bottom of the form.</p>
</chapter>
<chapter id="step-5-submit-the-salary-record" title="Step 5: Submit the Salary Record">
<p id="-ue51w5_68">After verifying the details:</p>
<list id="-ue51w5_69" type="decimal">
<li id="-ue51w5_70">Click the <include from="how-to-manage-salary_auto-include.topic" element-id="-ue51w5_72-snippet"/> button.</li>
<li id="-ue51w5_71">The salary record will be saved and can be accessed later in the payroll records.</li>
</list>
</chapter>
<chapter id="tips-for-accurate-salary-record-management" title="Tips for Accurate Salary Record Management">
<list id="-ue51w5_73">
<li id="-ue51w5_75"><include from="how-to-manage-salary_auto-include.topic" element-id="-ue51w5_78-snippet"/>: Ensure the bonuses and deductions are correctly added before submission.</li>
<li id="-ue51w5_76"><include from="how-to-manage-salary_auto-include.topic" element-id="-ue51w5_79-snippet"/>: Use consistent payment methods to simplify auditing.</li>
<li id="-ue51w5_77"><include from="how-to-manage-salary_auto-include.topic" element-id="-ue51w5_80-snippet"/>: Add notes if there are any unique aspects about the salary payment to avoid confusion later.</li>
</list>
<chapter id="frequently-asked-questions-faqs" title="Frequently Asked Questions (FAQs)">
<p id="-ue51w5_81"><include from="how-to-manage-salary_auto-include.topic" element-id="-ue51w5_85-snippet"/><br id="-ue51w5_86"/>A: Navigate to the employee’s salary record and select the <include from="how-to-manage-salary_auto-include.topic" element-id="-ue51w5_87-snippet"/> option to make any necessary changes.</p>
<p id="-ue51w5_82"><include from="how-to-manage-salary_auto-include.topic" element-id="-ue51w5_88-snippet"/><br id="-ue51w5_89"/>A: Yes, go to the <include from="how-to-manage-salary_auto-include.topic" element-id="-ue51w5_90-snippet"/> section to view all past salary entries for each employee.</p>
<p id="-ue51w5_83"><include from="how-to-manage-salary_auto-include.topic" element-id="-ue51w5_91-snippet"/><br id="-ue51w5_92"/>A: For multiple deductions, sum up the total deduction and enter it in the <include from="how-to-manage-salary_auto-include.topic" element-id="-ue51w5_93-snippet"/> field.</p>
<p id="-ue51w5_84">By following these steps, you’ll ensure a smooth and efficient payroll process. If you have any additional questions, refer to the help documentation or contact support.</p>
</chapter>
</chapter> </topic>