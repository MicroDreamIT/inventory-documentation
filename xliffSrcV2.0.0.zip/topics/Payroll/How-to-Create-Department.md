<?xml version='1.0' encoding='UTF-8'?><topic xsi:noNamespaceSchemaLocation="https://resources.jetbrains.com/writerside/1.0/topic.v2.xsd" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" id="How-to-Create-Department" title="How to Create Department"> <title id="r9xl22_2">
How to Create Department
</title>
<p id="r9xl22_3">Start typing here...</p> </topic>