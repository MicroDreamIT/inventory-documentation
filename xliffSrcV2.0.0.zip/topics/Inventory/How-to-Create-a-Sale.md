<?xml version='1.0' encoding='UTF-8'?><topic xsi:noNamespaceSchemaLocation="https://resources.jetbrains.com/writerside/1.0/topic.v2.xsd" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" id="How-to-Create-a-Sale" title="How to Create a Sale"> <title id="z117tnd_2">
How to Create a Sale
</title>
<p id="z117tnd_3">Follow these steps to create a sale, ensuring all required details are set up for a smooth sales transaction.</p>
<tip id="z117tnd_4">
<p id="z117tnd_7"><include from="How-to-Create-a-Sale_auto-include.topic" element-id="z117tnd_8-snippet"/> Before creating a sale, ensure that the unit, bank, product category, brand, and customer information are set up in advance. This helps streamline the sales process.</p>
</tip>
<chapter id="prerequisites" title="Prerequisites">
<p id="z117tnd_9">Complete these setup steps for efficient sales management:</p>
<list id="z117tnd_10">
<li id="z117tnd_11"><include from="How-to-Create-a-Sale_auto-include.topic" element-id="z117tnd_16-snippet"/>: Define units of measurement for your products.</li>
<li id="z117tnd_12"><include from="How-to-Create-a-Sale_auto-include.topic" element-id="z117tnd_17-snippet"/>: Set up bank details to manage payments.</li>
<li id="z117tnd_13"><include from="How-to-Create-a-Sale_auto-include.topic" element-id="z117tnd_18-snippet"/>: Organize products into relevant categories.</li>
<li id="z117tnd_14"><include from="How-to-Create-a-Sale_auto-include.topic" element-id="z117tnd_19-snippet"/>: Specify the product brand for accurate tracking.</li>
<li id="z117tnd_15"><include from="How-to-Create-a-Sale_auto-include.topic" element-id="z117tnd_20-snippet"/>: Add customer details for tracking and managing sales.</li>
</list>
</chapter>
<chapter id="step-by-step-guide-to-creating-a-sale" title="Step-by-Step Guide to Creating a Sale">
<chapter id="1-select-product" title="1. Select Product">
<list id="z117tnd_25">
<li id="z117tnd_26"><include from="How-to-Create-a-Sale_auto-include.topic" element-id="z117tnd_28-snippet"/>: Go to the product search panel.</li>
<li id="z117tnd_27"><include from="How-to-Create-a-Sale_auto-include.topic" element-id="z117tnd_29-snippet"/>: Choose the product from the list that you wish to sell.</li>
</list>
</chapter>
<chapter id="2-input-sale-details" title="2. Input Sale Details">
<list id="z117tnd_30">
<li id="z117tnd_31"><include from="How-to-Create-a-Sale_auto-include.topic" element-id="z117tnd_33-snippet"/>: Enter the quantity of the product to be sold, using the selected unit of measurement.</li>
<li id="z117tnd_32"><include from="How-to-Create-a-Sale_auto-include.topic" element-id="z117tnd_34-snippet"/>: Make necessary adjustments with price, discounts, or other applicable details.
<list id="z117tnd_35">
<li id="z117tnd_36"><include from="How-to-Create-a-Sale_auto-include.topic" element-id="z117tnd_37-snippet"/>: Adjustments allow for additions or subtractions to the total; they are not just balancing figures.</li>
</list>
</li>
</list>
</chapter>
<chapter id="3-payment-process" title="3. Payment Process">
<list id="z117tnd_38">
<li id="z117tnd_39"><include from="How-to-Create-a-Sale_auto-include.topic" element-id="z117tnd_41-snippet"/>: Choose the bank account where the payment will be deposited.</li>
<li id="z117tnd_40"><include from="How-to-Create-a-Sale_auto-include.topic" element-id="z117tnd_42-snippet"/>: Follow the steps to complete the payment process.</li>
</list>
</chapter>
<chapter id="4-finalize-the-sale" title="4. Finalize the Sale">
<list id="z117tnd_43">
<li id="z117tnd_45"><include from="How-to-Create-a-Sale_auto-include.topic" element-id="z117tnd_46-snippet"/>: After entering details and processing payment, you can:
<list id="z117tnd_47">
<li id="z117tnd_48">Print the sales receipt for records.</li>
<li id="z117tnd_49">View the sale summary.</li>
<li id="z117tnd_50">Submit to finalize and save the sale record.</li>
</list>
</li>
</list>
<p id="z117tnd_44">This organized guide to creating a sale helps you maintain accuracy and efficiency, enhancing the overall sales workflow within your inventory management system.</p>
</chapter>
</chapter> </topic>