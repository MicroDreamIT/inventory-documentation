<?xml version='1.0' encoding='UTF-8'?><topic xsi:noNamespaceSchemaLocation="https://resources.jetbrains.com/writerside/1.0/topic.v2.xsd" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" id="How-to-Create-Unit-and-Unit-Mapping" title="How to Create Units and Unit Mappings"> <title id="-tj3que_2">
How to Create Units and Unit Mappings
</title>
<p id="-tj3que_3">This guide will help you create units and define unit mappings to ensure accurate measurements and conversions in your inventory management system.</p>
<tip id="-tj3que_4">
<p id="-tj3que_8"><include from="How-to-Create-Unit-and-Unit-Mapping_auto-include.topic" element-id="-tj3que_9-snippet"/> Before creating units and mappings, have a clear understanding of the primary units used in your sales and purchases.</p>
</tip>
<chapter id="prerequisites" title="Prerequisites">
<p id="-tj3que_10">To create units and mappings effectively, ensure the following:</p>
<list id="-tj3que_11">
<li id="-tj3que_12"><include from="How-to-Create-Unit-and-Unit-Mapping_auto-include.topic" element-id="-tj3que_15-snippet"/>: Have a list of units needed for your inventory.</li>
<li id="-tj3que_13"><include from="How-to-Create-Unit-and-Unit-Mapping_auto-include.topic" element-id="-tj3que_16-snippet"/>: Determine primary units for products to streamline sales and purchases.</li>
<li id="-tj3que_14"><include from="How-to-Create-Unit-and-Unit-Mapping_auto-include.topic" element-id="-tj3que_17-snippet"/>: Plan out conversions between different units for accurate measurements.</li>
</list>
</chapter>
<chapter id="creating-units" title="Creating Units">
<p id="-tj3que_18">Follow these steps to create new units:</p>
<chapter id="1-navigate-to-the-units-section" title="1. Navigate to the Units Section">
<list id="-tj3que_21">
<li id="-tj3que_22"><include from="How-to-Create-Unit-and-Unit-Mapping_auto-include.topic" element-id="-tj3que_23-snippet"/>: Open the system menu and select the &amp;quot;Units&amp;quot; section.</li>
</list>
</chapter>
<chapter id="2-create-a-new-unit" title="2. Create a New Unit">
<list id="-tj3que_24">
<li id="-tj3que_25"><include from="How-to-Create-Unit-and-Unit-Mapping_auto-include.topic" element-id="-tj3que_29-snippet"/>: Click on the &amp;quot;Add New Unit&amp;quot; button.</li>
<li id="-tj3que_26"><include from="How-to-Create-Unit-and-Unit-Mapping_auto-include.topic" element-id="-tj3que_30-snippet"/>: Input the unit name (e.g., kilogram, piece).</li>
<li id="-tj3que_27"><include from="How-to-Create-Unit-and-Unit-Mapping_auto-include.topic" element-id="-tj3que_31-snippet"/>: Choose the primary unit for the product, if applicable.</li>
<li id="-tj3que_28"><include from="How-to-Create-Unit-and-Unit-Mapping_auto-include.topic" element-id="-tj3que_32-snippet"/>: Click &amp;quot;Save&amp;quot; to create the unit.</li>
</list>
</chapter>
</chapter>
<chapter id="creating-unit-mappings" title="Creating Unit Mappings">
<p id="-tj3que_33">Define conversion values to map units for accurate measurements:</p>
<chapter id="1-navigate-to-the-unit-mappings-section" title="1. Navigate to the Unit Mappings Section">
<list id="-tj3que_36">
<li id="-tj3que_37"><include from="How-to-Create-Unit-and-Unit-Mapping_auto-include.topic" element-id="-tj3que_38-snippet"/>: Open the system menu and select the &amp;quot;Unit Mappings&amp;quot; section.</li>
</list>
</chapter>
<chapter id="2-create-a-new-unit-mapping" title="2. Create a New Unit Mapping">
<list id="-tj3que_39">
<li id="-tj3que_41"><include from="How-to-Create-Unit-and-Unit-Mapping_auto-include.topic" element-id="-tj3que_47-snippet"/>: Click on the &amp;quot;Add New Mapping&amp;quot; button.</li>
<li id="-tj3que_42"><include from="How-to-Create-Unit-and-Unit-Mapping_auto-include.topic" element-id="-tj3que_48-snippet"/>: Choose the starting unit (e.g., Feet).</li>
<li id="-tj3que_43"><include from="How-to-Create-Unit-and-Unit-Mapping_auto-include.topic" element-id="-tj3que_49-snippet"/>: Specify the conversion factor for the &amp;quot;From&amp;quot; unit (e.g., 1).</li>
<li id="-tj3que_44"><include from="How-to-Create-Unit-and-Unit-Mapping_auto-include.topic" element-id="-tj3que_50-snippet"/>: Choose the target unit (e.g., Inch).</li>
<li id="-tj3que_45"><include from="How-to-Create-Unit-and-Unit-Mapping_auto-include.topic" element-id="-tj3que_51-snippet"/>: Specify the conversion factor for the &amp;quot;To&amp;quot; unit (e.g., 12).</li>
<li id="-tj3que_46"><include from="How-to-Create-Unit-and-Unit-Mapping_auto-include.topic" element-id="-tj3que_52-snippet"/>: Click &amp;quot;Save&amp;quot; to finalize the unit mapping.</li>
</list>
<p id="-tj3que_40">This setup ensures accurate and consistent unit conversions, enabling better inventory tracking and management.</p>
</chapter>
</chapter> </topic>