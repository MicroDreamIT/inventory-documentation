<?xml version='1.0' encoding='UTF-8'?><topic xsi:noNamespaceSchemaLocation="https://resources.jetbrains.com/writerside/1.0/topic.v2.xsd" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" id="How-to-Create-Unit-and-Unit-Mapping" title="How to Create Units and Unit Mappings"> <title id="bvzc7i_2">
How to Create Units and Unit Mappings
</title>
<p id="bvzc7i_3">This guide will help you create units and define unit mappings to ensure accurate measurements and conversions in your inventory management system.</p>
<tip id="bvzc7i_4">
<p id="bvzc7i_8"><include from="How-to-Create-Unit-and-Unit-Mapping_auto-include.topic" element-id="bvzc7i_9-snippet"/> Before creating units and mappings, have a clear understanding of the primary units used in your sales and purchases.</p>
</tip>
<chapter id="prerequisites" title="Prerequisites">
<p id="bvzc7i_10">To create units and mappings effectively, ensure the following:</p>
<list id="bvzc7i_11">
<li id="bvzc7i_12"><include from="How-to-Create-Unit-and-Unit-Mapping_auto-include.topic" element-id="bvzc7i_15-snippet"/>: Have a list of units needed for your inventory.</li>
<li id="bvzc7i_13"><include from="How-to-Create-Unit-and-Unit-Mapping_auto-include.topic" element-id="bvzc7i_16-snippet"/>: Determine primary units for products to streamline sales and purchases.</li>
<li id="bvzc7i_14"><include from="How-to-Create-Unit-and-Unit-Mapping_auto-include.topic" element-id="bvzc7i_17-snippet"/>: Plan out conversions between different units for accurate measurements.</li>
</list>
</chapter>
<chapter id="creating-units" title="Creating Units">
<p id="bvzc7i_18">Follow these steps to create new units:</p>
<chapter id="1-navigate-to-the-units-section" title="1. Navigate to the Units Section">
<list id="bvzc7i_21">
<li id="bvzc7i_22"><include from="How-to-Create-Unit-and-Unit-Mapping_auto-include.topic" element-id="bvzc7i_23-snippet"/>: Open the system menu and select the &amp;quot;Units&amp;quot; section.</li>
</list>
</chapter>
<chapter id="2-create-a-new-unit" title="2. Create a New Unit">
<list id="bvzc7i_24">
<li id="bvzc7i_25"><include from="How-to-Create-Unit-and-Unit-Mapping_auto-include.topic" element-id="bvzc7i_29-snippet"/>: Click on the &amp;quot;Add New Unit&amp;quot; button.</li>
<li id="bvzc7i_26"><include from="How-to-Create-Unit-and-Unit-Mapping_auto-include.topic" element-id="bvzc7i_30-snippet"/>: Input the unit name (e.g., kilogram, piece).</li>
<li id="bvzc7i_27"><include from="How-to-Create-Unit-and-Unit-Mapping_auto-include.topic" element-id="bvzc7i_31-snippet"/>: Choose the primary unit for the product, if applicable.</li>
<li id="bvzc7i_28"><include from="How-to-Create-Unit-and-Unit-Mapping_auto-include.topic" element-id="bvzc7i_32-snippet"/>: Click &amp;quot;Save&amp;quot; to create the unit.</li>
</list>
</chapter>
</chapter>
<chapter id="creating-unit-mappings" title="Creating Unit Mappings">
<p id="bvzc7i_33">Define conversion values to map units for accurate measurements:</p>
<chapter id="1-navigate-to-the-unit-mappings-section" title="1. Navigate to the Unit Mappings Section">
<list id="bvzc7i_36">
<li id="bvzc7i_37"><include from="How-to-Create-Unit-and-Unit-Mapping_auto-include.topic" element-id="bvzc7i_38-snippet"/>: Open the system menu and select the &amp;quot;Unit Mappings&amp;quot; section.</li>
</list>
</chapter>
<chapter id="2-create-a-new-unit-mapping" title="2. Create a New Unit Mapping">
<list id="bvzc7i_39">
<li id="bvzc7i_41"><include from="How-to-Create-Unit-and-Unit-Mapping_auto-include.topic" element-id="bvzc7i_47-snippet"/>: Click on the &amp;quot;Add New Mapping&amp;quot; button.</li>
<li id="bvzc7i_42"><include from="How-to-Create-Unit-and-Unit-Mapping_auto-include.topic" element-id="bvzc7i_48-snippet"/>: Choose the starting unit (e.g., Feet).</li>
<li id="bvzc7i_43"><include from="How-to-Create-Unit-and-Unit-Mapping_auto-include.topic" element-id="bvzc7i_49-snippet"/>: Specify the conversion factor for the &amp;quot;From&amp;quot; unit (e.g., 1).</li>
<li id="bvzc7i_44"><include from="How-to-Create-Unit-and-Unit-Mapping_auto-include.topic" element-id="bvzc7i_50-snippet"/>: Choose the target unit (e.g., Inch).</li>
<li id="bvzc7i_45"><include from="How-to-Create-Unit-and-Unit-Mapping_auto-include.topic" element-id="bvzc7i_51-snippet"/>: Specify the conversion factor for the &amp;quot;To&amp;quot; unit (e.g., 12).</li>
<li id="bvzc7i_46"><include from="How-to-Create-Unit-and-Unit-Mapping_auto-include.topic" element-id="bvzc7i_52-snippet"/>: Click &amp;quot;Save&amp;quot; to finalize the unit mapping.</li>
</list>
<p id="bvzc7i_40">This setup ensures accurate and consistent unit conversions, enabling better inventory tracking and management.</p>
</chapter>
</chapter> </topic>