<?xml version='1.0' encoding='UTF-8'?><topic xsi:noNamespaceSchemaLocation="https://resources.jetbrains.com/writerside/1.0/topic.v2.xsd" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" id="How-to" title="How to"> <title id="l7ibnm_2">
How to
</title>
<p id="l7ibnm_3">A How-to article is an action-oriented type of document.
It explains how to perform a specific task or solve a problem, and usually contains a sequence of steps.
Start with a short introductory paragraph that explains what users will accomplish by following this procedure,
what they need to perform it for, or define the target audience of the doc.</p>
<note id="l7ibnm_4">
<p id="l7ibnm_7"><include from="How-to_auto-include.topic" element-id="l7ibnm_9-snippet"/></p>
<p id="l7ibnm_8">You can change the element to <emphasis id="l7ibnm_10">tip</emphasis> or <emphasis id="l7ibnm_11">warning</emphasis> by renaming the style attribute below.</p>
</note>
<chapter id="before-you-start" title="Before you start">
<p id="l7ibnm_12">It is good practice to list the prerequisites that are required or recommended.</p>
<p id="l7ibnm_13">Make sure that:</p>
<list id="l7ibnm_14">
<li id="l7ibnm_15">First prerequisite</li>
<li id="l7ibnm_16">Second prerequisite</li>
</list>
</chapter>
<chapter id="how-to-perform-a-task" title="How to perform a task">
<p id="l7ibnm_17">Some introductory information.</p>
<list id="l7ibnm_18" type="decimal">
<li id="l7ibnm_19">
<p id="l7ibnm_22">Step with a code block</p> <code-block id="l7ibnm_23" lang="bash">
 run this --that
</code-block>
</li>
<li id="l7ibnm_20">
<p id="l7ibnm_24">Step with a <a href="https://www.jetbrains.com" id="l7ibnm_25">link</a></p>
</li>
<li id="l7ibnm_21">
<p id="l7ibnm_26">Step with a list.</p>
<list id="l7ibnm_27">
<li id="l7ibnm_28">List item</li>
<li id="l7ibnm_29">List item</li>
<li id="l7ibnm_30">List item</li>
</list>
</li>
</list>
</chapter> </topic>