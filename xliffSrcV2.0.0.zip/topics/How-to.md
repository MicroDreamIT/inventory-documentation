<?xml version='1.0' encoding='UTF-8'?><topic xsi:noNamespaceSchemaLocation="https://resources.jetbrains.com/writerside/1.0/topic.v2.xsd" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" id="How-to" title="How to Install XeroInput"> <title id="ntj9p8_2">
How to Install XeroInput
</title>
<p id="ntj9p8_3">Below is an updated step-by-step guide to installing a Laravel application on an Ubuntu system that includes both
Apache and Nginx setup options. This guide assumes PHP and MySQL are already installed.</p>
<chapter id="before-you-start" title="Before you start">
<p id="ntj9p8_8">To run this Laravel project, ensure your environment meets the following requirements:</p>
<list id="ntj9p8_9">
<li id="ntj9p8_12"><include from="How-to_auto-include.topic" element-id="ntj9p8_16-snippet"/> version <include from="How-to_auto-include.topic" element-id="ntj9p8_17-snippet"/> or higher</li>
<li id="ntj9p8_13"><include from="How-to_auto-include.topic" element-id="ntj9p8_18-snippet"/> for dependency management</li>
<li id="ntj9p8_14">A supported <include from="How-to_auto-include.topic" element-id="ntj9p8_19-snippet"/> like Apache or Nginx</li>
<li id="ntj9p8_15"><include from="How-to_auto-include.topic" element-id="ntj9p8_20-snippet"/> or <include from="How-to_auto-include.topic" element-id="ntj9p8_21-snippet"/> for the database</li>
</list>
<chapter id="required-php-extensions" title="Required PHP Extensions">
<p id="ntj9p8_22">Make sure these extensions are installed and enabled:</p>
<list id="ntj9p8_23">
<li id="ntj9p8_26"><include from="How-to_auto-include.topic" element-id="ntj9p8_31-snippet"/></li>
<li id="ntj9p8_27"><include from="How-to_auto-include.topic" element-id="ntj9p8_32-snippet"/></li>
<li id="ntj9p8_28"><include from="How-to_auto-include.topic" element-id="ntj9p8_33-snippet"/></li>
<li id="ntj9p8_29"><include from="How-to_auto-include.topic" element-id="ntj9p8_34-snippet"/></li>
<li id="ntj9p8_30"><include from="How-to_auto-include.topic" element-id="ntj9p8_35-snippet"/></li>
</list>
<p id="ntj9p8_24">For optional features, you may need:</p>
<list id="ntj9p8_25">
<li id="ntj9p8_36"><include from="How-to_auto-include.topic" element-id="ntj9p8_38-snippet"/> (for frontend assets if using <include from="How-to_auto-include.topic" element-id="ntj9p8_39-snippet"/>)</li>
<li id="ntj9p8_37"><include from="How-to_auto-include.topic" element-id="ntj9p8_40-snippet"/> (if using <include from="How-to_auto-include.topic" element-id="ntj9p8_41-snippet"/> for local development)</li>
</list>
</chapter>
<chapter id="additional-packages" title="Additional Packages">
<p id="ntj9p8_42">This project uses various Laravel packages, including:</p>
<list id="ntj9p8_43">
<li id="ntj9p8_46"><include from="How-to_auto-include.topic" element-id="ntj9p8_50-snippet"/> for API authentication</li>
<li id="ntj9p8_47"><include from="How-to_auto-include.topic" element-id="ntj9p8_51-snippet"/> for UI scaffolding</li>
<li id="ntj9p8_48"><include from="How-to_auto-include.topic" element-id="ntj9p8_52-snippet"/> for HTTP requests</li>
<li id="ntj9p8_49"><include from="How-to_auto-include.topic" element-id="ntj9p8_53-snippet"/> for handling spreadsheets</li>
</list>
<p id="ntj9p8_44">Here's a condensed and structured guide for installing a Laravel application, complete with both Apache and Nginx server options and the cPanel setup, along with steps for importing databases.</p>
<hr id="ntj9p8_45"/>
</chapter>
</chapter>
<chapter id="installation-steps-for-laravel-on-ubuntu">
<title id="ntj9p8_54">
<include from="How-to_auto-include.topic" element-id="ntj9p8_63-snippet"/>
</title>
<chapter id="prerequisites">
<title id="ntj9p8_64">
<include from="How-to_auto-include.topic" element-id="ntj9p8_66-snippet"/>
</title>
<p id="ntj9p8_65">Ensure PHP and MySQL are installed on your Ubuntu system.</p>
</chapter>
<chapter id="step-1-update-system-packages">
<title id="ntj9p8_67">
<include from="How-to_auto-include.topic" element-id="ntj9p8_69-snippet"/>
</title> <code-block id="ntj9p8_68" lang="bash">
sudo apt update
sudo apt upgrade -y
</code-block>
</chapter>
<chapter id="step-2-install-composer">
<title id="ntj9p8_70">
<include from="How-to_auto-include.topic" element-id="ntj9p8_72-snippet"/>
</title> <code-block id="ntj9p8_71" lang="bash">
sudo apt install curl -y
curl -sS https://getcomposer.org/installer | php
sudo mv composer.phar /usr/local/bin/composer
composer --version  # Verify installation
</code-block>
</chapter>
<chapter id="step-3-install-laravel">
<title id="ntj9p8_73">
<include from="How-to_auto-include.topic" element-id="ntj9p8_75-snippet"/>
</title> <code-block id="ntj9p8_74" lang="bash">
cd /var/www/html
composer create-project --prefer-dist laravel/laravel xeroInput
</code-block>
</chapter>
<chapter id="step-4-set-directory-permissions">
<title id="ntj9p8_76">
<include from="How-to_auto-include.topic" element-id="ntj9p8_78-snippet"/>
</title> <code-block id="ntj9p8_77" lang="bash">
sudo chown -R www-data:www-data /var/www/html/xeroInput
sudo chmod -R 755 /var/www/html/xeroInput/storage
sudo chmod -R 755 /var/www/html/xeroInput/bootstrap/cache
</code-block>
</chapter>
<chapter id="step-5-configure-environment">
<title id="ntj9p8_79">
<include from="How-to_auto-include.topic" element-id="ntj9p8_81-snippet"/>
</title>
<list id="ntj9p8_80" type="decimal">
<li id="ntj9p8_82">
<p id="ntj9p8_84">Navigate to the Laravel project directory:</p> <code-block id="ntj9p8_85" lang="bash">
cd /var/www/html/xeroInput
cp .env.example .env
php artisan key:generate
</code-block>
</li>
<li id="ntj9p8_83">
<p id="ntj9p8_86">Update database configuration in <include from="How-to_auto-include.topic" element-id="ntj9p8_88-snippet"/>:</p> <code-block id="ntj9p8_87" lang="env">
DB_CONNECTION=mysql
DB_HOST=127.0.0.1
DB_PORT=3306
DB_DATABASE=xero_input
DB_USERNAME=your_database_user
DB_PASSWORD=your_database_password
</code-block>
</li>
</list>
</chapter>
<chapter id="step-6-create-database">
<title id="ntj9p8_89">
<include from="How-to_auto-include.topic" element-id="ntj9p8_91-snippet"/>
</title>
<list id="ntj9p8_90" type="decimal">
<li id="ntj9p8_92">
<p id="ntj9p8_94">Access MySQL and create the database:</p> <code-block id="ntj9p8_95" lang="bash">
sudo mysql -u root -p
</code-block>
</li>
<li id="ntj9p8_93">
<p id="ntj9p8_96">Run the following in the MySQL shell:</p> <code-block id="ntj9p8_97" lang="sql">
CREATE DATABASE xero_input;
GRANT ALL PRIVILEGES ON xero_input.* TO 'your_database_user'@'localhost' IDENTIFIED BY 'your_database_password';
FLUSH PRIVILEGES;
EXIT;
</code-block>
</li>
</list>
</chapter>
<chapter id="step-7-configure-web-server-choose-apache-or-nginx">
<title id="ntj9p8_98">
<include from="How-to_auto-include.topic" element-id="ntj9p8_101-snippet"/>
</title>
<chapter id="option-1-apache">
<title id="ntj9p8_102">
<include from="How-to_auto-include.topic" element-id="ntj9p8_104-snippet"/>
</title>
<list id="ntj9p8_103" type="decimal">
<li id="ntj9p8_105">
<p id="ntj9p8_108">Install and configure Apache:</p> <code-block id="ntj9p8_109" lang="bash">
sudo apt install apache2 -y
sudo a2enmod rewrite
sudo nano /etc/apache2/sites-available/xeroInput.conf
</code-block>
</li>
<li id="ntj9p8_106">
<p id="ntj9p8_110">Add this configuration in <include from="How-to_auto-include.topic" element-id="ntj9p8_112-snippet"/>:</p> <code-block id="ntj9p8_111" lang="apache">
&amp;lt;VirtualHost *:80&amp;gt;
    ServerAdmin admin@example.com
    DocumentRoot /var/www/html/xeroInput/public
    ServerName example.com
    ServerAlias www.example.com
    &amp;lt;Directory /var/www/html/xeroInput&amp;gt;
        Options Indexes FollowSymLinks
        AllowOverride All
        Require all granted
    &amp;lt;/Directory&amp;gt;
&amp;lt;/VirtualHost&amp;gt;
</code-block>
</li>
<li id="ntj9p8_107">
<p id="ntj9p8_113">Enable the new site and reload Apache:</p> <code-block id="ntj9p8_114" lang="bash">
sudo a2ensite xeroInput.conf
sudo systemctl reload apache2
</code-block>
</li>
</list>
</chapter>
<chapter id="option-2-nginx">
<title id="ntj9p8_115">
<include from="How-to_auto-include.topic" element-id="ntj9p8_118-snippet"/>
</title>
<list id="ntj9p8_116" type="decimal">
<li id="ntj9p8_119">
<p id="ntj9p8_122">Install Nginx and create a configuration file:</p> <code-block id="ntj9p8_123" lang="bash">
sudo apt install nginx -y
sudo nano /etc/nginx/sites-available/xeroInput
</code-block>
</li>
<li id="ntj9p8_120">
<p id="ntj9p8_124">Add the following configuration in <include from="How-to_auto-include.topic" element-id="ntj9p8_126-snippet"/>:</p> <code-block id="ntj9p8_125" lang="nginx">
server {
    listen 80;
    server_name example.com www.example.com;
    root /var/www/html/xeroInput/public;
    index index.php index.html index.htm;
    location / {
        try_files $uri $uri/ /index.php?$query_string;
    }
    location ~ \.php$ {
        include snippets/fastcgi-php.conf;
        fastcgi_pass unix:/var/run/php/php7.4-fpm.sock;
        fastcgi_param SCRIPT_FILENAME $document_root$fastcgi_script_name;
        include fastcgi_params;
    }
}
</code-block>
</li>
<li id="ntj9p8_121">
<p id="ntj9p8_127">Enable the site and restart Nginx:</p> <code-block id="ntj9p8_128" lang="bash">
sudo ln -s /etc/nginx/sites-available/xeroInput /etc/nginx/sites-enabled/
sudo nginx -t
sudo systemctl restart nginx
</code-block>
</li>
</list>
<hr id="ntj9p8_117"/>
</chapter>
</chapter>
</chapter>
<chapter id="setting-up-laravel-on-cpanel">
<title id="ntj9p8_129">
<include from="How-to_auto-include.topic" element-id="ntj9p8_132-snippet"/>
</title>
<list id="ntj9p8_130" type="decimal">
<li id="ntj9p8_133">
<p id="ntj9p8_141"><include from="How-to_auto-include.topic" element-id="ntj9p8_142-snippet"/>: Access via <include from="How-to_auto-include.topic" element-id="ntj9p8_143-snippet"/>.</p>
</li>
<li id="ntj9p8_134">
<p id="ntj9p8_144"><include from="How-to_auto-include.topic" element-id="ntj9p8_145-snippet"/> in MySQL® Databases section.</p>
</li>
<li id="ntj9p8_135">
<p id="ntj9p8_146"><include from="How-to_auto-include.topic" element-id="ntj9p8_148-snippet"/>: Use cPanel Terminal to verify or install Composer:</p> <code-block id="ntj9p8_147" lang="bash">
composer --version
</code-block>
</li>
<li id="ntj9p8_136">
<p id="ntj9p8_149"><include from="How-to_auto-include.topic" element-id="ntj9p8_151-snippet"/>:</p>
<list id="ntj9p8_150">
<li id="ntj9p8_152">Use File Manager to upload and extract files to your subdomain directory.</li>
<li id="ntj9p8_153">Alternatively, use FTP to upload the Laravel files.</li>
</list>
</li>
<li id="ntj9p8_137">
<p id="ntj9p8_154"><include from="How-to_auto-include.topic" element-id="ntj9p8_156-snippet"/>:</p>
<list id="ntj9p8_155">
<li id="ntj9p8_157">Rename <include from="How-to_auto-include.topic" element-id="ntj9p8_159-snippet"/> to <include from="How-to_auto-include.topic" element-id="ntj9p8_160-snippet"/>.</li>
<li id="ntj9p8_158">Edit database configuration in <include from="How-to_auto-include.topic" element-id="ntj9p8_161-snippet"/>.</li>
</list>
</li>
<li id="ntj9p8_138">
<p id="ntj9p8_162"><include from="How-to_auto-include.topic" element-id="ntj9p8_164-snippet"/>:</p>
<list id="ntj9p8_163">
<li id="ntj9p8_165">Set 755 permissions on <include from="How-to_auto-include.topic" element-id="ntj9p8_166-snippet"/> and <include from="How-to_auto-include.topic" element-id="ntj9p8_167-snippet"/> directories.</li>
</list>
</li>
<li id="ntj9p8_139">
<p id="ntj9p8_168"><include from="How-to_auto-include.topic" element-id="ntj9p8_170-snippet"/>:</p>
<list id="ntj9p8_169">
<li id="ntj9p8_171">
<p id="ntj9p8_172">Ensure <include from="How-to_auto-include.topic" element-id="ntj9p8_174-snippet"/> contains:</p> <code-block id="ntj9p8_173" lang="apache">
&amp;lt;IfModule mod_rewrite.c&amp;gt;
RewriteEngine On
RewriteCond %{REQUEST_FILENAME} !-d
RewriteCond %{REQUEST_FILENAME} !-f
RewriteRule ^ index.php [L]
&amp;lt;/IfModule&amp;gt;
</code-block>
</li>
</list>
</li>
<li id="ntj9p8_140">
<p id="ntj9p8_175"><include from="How-to_auto-include.topic" element-id="ntj9p8_177-snippet"/>:</p> <code-block id="ntj9p8_176" lang="bash">
* * * * * php /home/username/path_to_laravel_project/artisan schedule:run &amp;gt;&amp;gt; /dev/null 2&amp;gt;&amp;amp;1
</code-block>
</li>
</list>
<hr id="ntj9p8_131"/>
</chapter>
<chapter id="final-step-database-configuration">
<title id="ntj9p8_178">
<include from="How-to_auto-include.topic" element-id="ntj9p8_181-snippet"/>
</title>
<chapter id="option-1-import-sql">
<title id="ntj9p8_182">
<include from="How-to_auto-include.topic" element-id="ntj9p8_184-snippet"/>
</title>
<list id="ntj9p8_183" type="decimal">
<li id="ntj9p8_185">
<p id="ntj9p8_186">Transfer <include from="How-to_auto-include.topic" element-id="ntj9p8_188-snippet"/> to the server and import in MySQL:</p> <code-block id="ntj9p8_187" lang="bash">
sudo mysql -u root -p
USE xero_input;
SOURCE /path/to/xeroInput.sql;
</code-block>
</li>
</list>
</chapter>
<chapter id="option-2-run-migrations-and-seeders">
<title id="ntj9p8_189">
<include from="How-to_auto-include.topic" element-id="ntj9p8_193-snippet"/>
</title>
<list id="ntj9p8_190" type="decimal">
<li id="ntj9p8_194">
<p id="ntj9p8_195">Ensure <include from="How-to_auto-include.topic" element-id="ntj9p8_197-snippet"/> is configured and run:</p> <code-block id="ntj9p8_196" lang="bash">
php artisan migrate:fresh --seed
</code-block>
</li>
</list>
<p id="ntj9p8_191">Access the application by navigating to your server's IP or domain.</p>
<p id="ntj9p8_192">Congratulations! You’ve successfully set up your Laravel application.</p>
</chapter>
</chapter> </topic>