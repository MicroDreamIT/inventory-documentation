<?xml version='1.0' encoding='UTF-8'?><topic xsi:noNamespaceSchemaLocation="https://resources.jetbrains.com/writerside/1.0/topic.v2.xsd" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" id="starter-topic" title="About v2.0.0"> <title id="vb4bvj_2">
About v2.0.0
</title>

<chapter id="add-new-topics" title="Add new topics">
<p id="vb4bvj_21">You can create empty topics, or choose a template for different types of content that contains some boilerplate structure to help you get started:</p>
<img src="new_topic_options.png" alt="Create new topic options" width="290" border-effect="line" id="vb4bvj_22"/>
</chapter>
<chapter id="write-content" title="Write content">
<p id="vb4bvj_9">%product% supports two types of markup: Markdown and XML.
When you create a new help article, you can choose between two topic types, but this doesn't mean you have to stick to a single format.
You can author content in Markdown and extend it with semantic attributes or inject entire XML elements.</p>
</chapter>
<chapter id="inject-xml" title="Inject XML">
<p id="vb4bvj_10">For example, this is how you inject a procedure:</p>
<procedure id="inject-a-procedure" title="Inject a procedure"> <step id="vb4bvj_12"> <p id="vb4bvj_14">Start typing and select a procedure type from the completion suggestions:</p> <img src="completion_procedure.png" alt="completion suggestions for procedure" border-effect="line" id="vb4bvj_15"/> </step> <step id="vb4bvj_13"> <p id="vb4bvj_23">Press <include from="starter-topic_auto-include.topic" element-id="vb4bvj_24-snippet"/> or <include from="starter-topic_auto-include.topic" element-id="vb4bvj_25-snippet"/> to insert the markup.</p> </step>
</procedure>
</chapter>
<chapter id="add-interactive-elements" title="Add interactive elements">
<chapter id="tabs" title="Tabs">
<p id="vb4bvj_26">To add switchable content, you can make use of tabs (inject them by starting to type <include from="starter-topic_auto-include.topic" element-id="vb4bvj_28-snippet"/> on a new line):</p>
<tabs id="vb4bvj_27"> <tab id="vb4bvj_29" title="Markdown"> <code-block id="vb4bvj_31" lang="plain text">![Alt Text](new_topic_options.png){ width=450 }</code-block> </tab> <tab id="vb4bvj_30" title="Semantic markup"> <code-block id="vb4bvj_32" lang="xml">
            &amp;lt;img src=&amp;quot;new_topic_options.png&amp;quot; alt=&amp;quot;Alt text&amp;quot; width=&amp;quot;450px&amp;quot;/&amp;gt;</code-block> </tab>
</tabs>
</chapter>
<chapter id="collapsible-blocks" title="Collapsible blocks">
<p id="vb4bvj_19">Apart from injecting entire XML elements, you can use attributes to configure the behavior of certain elements.
For example, you can collapse a chapter that contains non-essential information:</p>
<chapter id="supplementary-info" title="Supplementary info" collapsible="true">
<p id="vb4bvj_33">Content under a collapsible header will be collapsed by default,
but you can modify the behavior by adding the following attribute:
<include from="starter-topic_auto-include.topic" element-id="vb4bvj_34-snippet"/></p>
</chapter>
</chapter>
<chapter id="convert-selection-to-xml" title="Convert selection to XML">
<p id="vb4bvj_35">If you need to extend an element with more functions, you can convert selected content from Markdown to semantic markup.
For example, if you want to merge cells in a table, it's much easier to convert it to XML than do this in Markdown.
Position the caret anywhere in the table and press <include from="starter-topic_auto-include.topic" element-id="vb4bvj_37-snippet"/>:</p>
<img src="convert_table_to_xml.png" alt="Convert table to XML" width="706" border-effect="line" id="vb4bvj_36"/>
</chapter>
</chapter>
<chapter id="feedback-and-support" title="Feedback and support">
<p id="vb4bvj_38">Please report any issues, usability improvements, or feature requests to our
<a href="https://youtrack.jetbrains.com/newIssue?project=WRS" id="vb4bvj_41">YouTrack project</a>
(you will need to register).</p>
<p id="vb4bvj_39">You are welcome to join our
<a href="https://jb.gg/WRS_Slack" id="vb4bvj_42">public Slack workspace</a>.
Before you do, please read our <a href="https://plugins.jetbrains.com/plugin/20158-writerside/docs/writerside-code-of-conduct.html" id="vb4bvj_43">Code of conduct</a>.
We assume that you’ve read and acknowledged it before joining.</p>
<p id="vb4bvj_40">You can also always email us at <a href="mailto:writerside@jetbrains.com" id="vb4bvj_44">writerside@jetbrains.com</a>.</p>
</chapter>
<seealso id="vb4bvj_8"> <category ref="wrs" id="vb4bvj_45"> <a href="https://plugins.jetbrains.com/plugin/20158-writerside/docs/markup-reference.html" id="vb4bvj_46">Markup reference</a> <a href="https://plugins.jetbrains.com/plugin/20158-writerside/docs/manage-table-of-contents.html" id="vb4bvj_47">Reorder topics in the TOC</a> <a href="https://plugins.jetbrains.com/plugin/20158-writerside/docs/local-build.html" id="vb4bvj_48">Build and publish</a> <a href="https://plugins.jetbrains.com/plugin/20158-writerside/docs/configure-search.html" id="vb4bvj_49">Configure Search</a> </category>
</seealso> </topic>