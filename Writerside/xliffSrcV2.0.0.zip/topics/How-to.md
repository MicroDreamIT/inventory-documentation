<?xml version='1.0' encoding='UTF-8'?><topic xsi:noNamespaceSchemaLocation="https://resources.jetbrains.com/writerside/1.0/topic.v2.xsd" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" id="How-to" title="How to"> <title id="-tgx0lz_2">
How to
</title>
<p id="-tgx0lz_3">A How-to article is an action-oriented type of document.
It explains how to perform a specific task or solve a problem, and usually contains a sequence of steps.
Start with a short introductory paragraph that explains what users will accomplish by following this procedure,
what they need to perform it for, or define the target audience of the doc.</p>
<note id="-tgx0lz_4">
<p id="-tgx0lz_7"><include from="How-to_auto-include.topic" element-id="-tgx0lz_9-snippet"/></p>
<p id="-tgx0lz_8">You can change the element to <emphasis id="-tgx0lz_10">tip</emphasis> or <emphasis id="-tgx0lz_11">warning</emphasis> by renaming the style attribute below.</p>
</note>
<chapter id="before-you-start" title="Before you start">
<p id="-tgx0lz_12">It is good practice to list the prerequisites that are required or recommended.</p>
<p id="-tgx0lz_13">Make sure that:</p>
<list id="-tgx0lz_14">
<li id="-tgx0lz_15">First prerequisite</li>
<li id="-tgx0lz_16">Second prerequisite</li>
</list>
</chapter>
<chapter id="how-to-perform-a-task" title="How to perform a task">
<p id="-tgx0lz_17">Some introductory information.</p>
<list id="-tgx0lz_18" type="decimal">
<li id="-tgx0lz_19">
<p id="-tgx0lz_22">Step with a code block</p> <code-block id="-tgx0lz_23" lang="bash">
 run this --that
</code-block>
</li>
<li id="-tgx0lz_20">
<p id="-tgx0lz_24">Step with a <a href="https://www.jetbrains.com" id="-tgx0lz_25">link</a></p>
</li>
<li id="-tgx0lz_21">
<p id="-tgx0lz_26">Step with a list.</p>
<list id="-tgx0lz_27">
<li id="-tgx0lz_28">List item</li>
<li id="-tgx0lz_29">List item</li>
<li id="-tgx0lz_30">List item</li>
</list>
</li>
</list>
</chapter> </topic>