<?xml version='1.0' encoding='UTF-8'?><topic xsi:noNamespaceSchemaLocation="https://resources.jetbrains.com/writerside/1.0/topic.v2.xsd" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" id="starter-topic" title="About v2.0.0"> <title id="z5e5y54_2">
About v2.0.0
</title>

<chapter id="add-new-topics" title="Add new topics">
<p id="z5e5y54_9">You can create empty topics, or choose a template for different types of content that contains some boilerplate structure to help you get started:</p>
<img src="new_topic_options.png" alt="Create new topic options" width="290" border-effect="line" id="z5e5y54_10"/>
</chapter>
<chapter id="write-content" title="Write content">
<p id="z5e5y54_11">%product% supports two types of markup: Markdown and XML.
When you create a new help article, you can choose between two topic types, but this doesn't mean you have to stick to a single format.
You can author content in Markdown and extend it with semantic attributes or inject entire XML elements.</p>
</chapter>
<chapter id="inject-xml" title="Inject XML">
<p id="z5e5y54_12">For example, this is how you inject a procedure:</p>
<procedure id="inject-a-procedure" title="Inject a procedure"> <step id="z5e5y54_14"> <p id="z5e5y54_16">Start typing and select a procedure type from the completion suggestions:</p> <img src="completion_procedure.png" alt="completion suggestions for procedure" border-effect="line" id="z5e5y54_17"/> </step> <step id="z5e5y54_15"> <p id="z5e5y54_18">Press <include from="starter-topic_auto-include.topic" element-id="z5e5y54_19-snippet"/> or <include from="starter-topic_auto-include.topic" element-id="z5e5y54_20-snippet"/> to insert the markup.</p> </step>
</procedure>
</chapter>
<chapter id="add-interactive-elements" title="Add interactive elements">
<chapter id="tabs" title="Tabs">
<p id="z5e5y54_24">To add switchable content, you can make use of tabs (inject them by starting to type <include from="starter-topic_auto-include.topic" element-id="z5e5y54_26-snippet"/> on a new line):</p>
<tabs id="z5e5y54_25"> <tab id="z5e5y54_27" title="Markdown"> <code-block id="z5e5y54_29" lang="plain text">![Alt Text](new_topic_options.png){ width=450 }</code-block> </tab> <tab id="z5e5y54_28" title="Semantic markup"> <code-block id="z5e5y54_30" lang="xml">
            &amp;lt;img src=&amp;quot;new_topic_options.png&amp;quot; alt=&amp;quot;Alt text&amp;quot; width=&amp;quot;450px&amp;quot;/&amp;gt;</code-block> </tab>
</tabs>
</chapter>
<chapter id="collapsible-blocks" title="Collapsible blocks">
<p id="z5e5y54_31">Apart from injecting entire XML elements, you can use attributes to configure the behavior of certain elements.
For example, you can collapse a chapter that contains non-essential information:</p>
<chapter id="supplementary-info" title="Supplementary info" collapsible="true">
<p id="z5e5y54_33">Content under a collapsible header will be collapsed by default,
but you can modify the behavior by adding the following attribute:
<include from="starter-topic_auto-include.topic" element-id="z5e5y54_34-snippet"/></p>
</chapter>
</chapter>
<chapter id="convert-selection-to-xml" title="Convert selection to XML">
<p id="z5e5y54_35">If you need to extend an element with more functions, you can convert selected content from Markdown to semantic markup.
For example, if you want to merge cells in a table, it's much easier to convert it to XML than do this in Markdown.
Position the caret anywhere in the table and press <include from="starter-topic_auto-include.topic" element-id="z5e5y54_37-snippet"/>:</p>
<img src="convert_table_to_xml.png" alt="Convert table to XML" width="706" border-effect="line" id="z5e5y54_36"/>
</chapter>
</chapter>
<chapter id="feedback-and-support" title="Feedback and support">
<p id="z5e5y54_38">Please report any issues, usability improvements, or feature requests to our
<a href="https://youtrack.jetbrains.com/newIssue?project=WRS" id="z5e5y54_41">YouTrack project</a>
(you will need to register).</p>
<p id="z5e5y54_39">You are welcome to join our
<a href="https://jb.gg/WRS_Slack" id="z5e5y54_42">public Slack workspace</a>.
Before you do, please read our <a href="https://plugins.jetbrains.com/plugin/20158-writerside/docs/writerside-code-of-conduct.html" id="z5e5y54_43">Code of conduct</a>.
We assume that you’ve read and acknowledged it before joining.</p>
<p id="z5e5y54_40">You can also always email us at <a href="mailto:writerside@jetbrains.com" id="z5e5y54_44">writerside@jetbrains.com</a>.</p>
</chapter>
<seealso id="z5e5y54_8"> <category ref="wrs" id="z5e5y54_45"> <a href="https://plugins.jetbrains.com/plugin/20158-writerside/docs/markup-reference.html" id="z5e5y54_46">Markup reference</a> <a href="https://plugins.jetbrains.com/plugin/20158-writerside/docs/manage-table-of-contents.html" id="z5e5y54_47">Reorder topics in the TOC</a> <a href="https://plugins.jetbrains.com/plugin/20158-writerside/docs/local-build.html" id="z5e5y54_48">Build and publish</a> <a href="https://plugins.jetbrains.com/plugin/20158-writerside/docs/configure-search.html" id="z5e5y54_49">Configure Search</a> </category>
</seealso> </topic>